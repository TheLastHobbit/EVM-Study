import './App.css' 

import ConnectBtn from './ConnectBtn'
import Bank from "./Bank"
const App = () => {

  return (
    <>
      <div className="app">  
        <ConnectBtn />
        
        <Bank/>
      </div>
    </>
  )
}

export default App
